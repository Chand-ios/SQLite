//
//  ModelClass.swift
//  SqliteTask
//
//  Created by eAlphaMac2 on 25/09/20.
//

import Foundation
//AssertID, Battery Status, Battery Health,Battery Useful Life, Create date and flag
class ModelClass
{
    var Id: Int = 0
    var AssertID : Int = 0
    var battery_Status: String = ""
    var battery_Health : String = ""
    var battery_Useful_Life : String = ""
    var Create_date : String = ""
    var flag: String = "0"
    
    init(Id: Int,AssertID:Int, battery_Status:String, battery_Health:String, battery_Useful_Life: String, Create_date:String,flag:String)
    {
        self.Id = Id
        self.AssertID = AssertID
        self.battery_Status = battery_Status
        self.battery_Health = battery_Health
        self.battery_Useful_Life = battery_Useful_Life
        self.Create_date = Create_date
        self.flag = flag
        
        
    }
    
}

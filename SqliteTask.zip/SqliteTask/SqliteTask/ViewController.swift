//
//  ViewController.swift
//  SqliteTask
//
//  Created by eAlphaMac2 on 25/09/20.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource{
    var battery:[ModelClass] = []
    var db:DataBaseView = DataBaseView()
    private let cellID = "BatteryTableViewCell"
    @IBOutlet weak var tableView: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
       

        battery = db.read()
        tableView.delegate = self
        tableView.dataSource = self
       // db.deleteByID(id: 1)
       
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        battery = db.read()
        tableView.reloadData()
        
    
       
    }
    @IBAction func AddAction(_ sender: Any) {
        let  navVC = self.storyboard?.instantiateViewController(withIdentifier: "InsertUpdateViewController") as! InsertUpdateViewController
        self.navigationController?.pushViewController(navVC, animated: true)
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return battery.count
        }
     
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let batteryModel = battery[indexPath.row]
            let cell = tableView.dequeueReusableCell(withIdentifier: "BatteryTableViewCell", for: indexPath) as! BatteryTableViewCell
            cell.selectionStyle = .none
            cell.assertID.text = "AssertID :  " + String(batteryModel.AssertID)
            cell.statusLbl.text = "Battery Status :  " + batteryModel.battery_Status
            cell.healthLbl.text = "Battery Health :  " + batteryModel.battery_Health
            cell.lifeLbl.text = "Battery Useful Life :  " + batteryModel.battery_Useful_Life
            cell.dateLbl.text = "Created Date :  " + batteryModel.Create_date

            
            
            return cell
        }
        func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
               return 230
            
        }
        func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            
            let batteryModel = battery[indexPath.row]
            //db.deleteByID(id: batteryModel.AssertID)
            let  navVC = self.storyboard?.instantiateViewController(withIdentifier: "InsertUpdateViewController") as! InsertUpdateViewController
            navVC.data = batteryModel
            self.navigationController?.pushViewController(navVC, animated: true)
            
        }
    
}
//MARK:- Tableview delegate and datasource methods




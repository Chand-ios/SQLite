//
//  BatteryTableViewCell.swift
//  SqliteTask
//
//  Created by eAlphaMac2 on 25/09/20.
//

import UIKit

class BatteryTableViewCell: UITableViewCell {
    @IBOutlet weak var assertID: UILabel!
    @IBOutlet weak var statusLbl: UILabel!
    @IBOutlet weak var healthLbl: UILabel!
    @IBOutlet weak var lifeLbl: UILabel!
    @IBOutlet weak var dateLbl: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    


    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

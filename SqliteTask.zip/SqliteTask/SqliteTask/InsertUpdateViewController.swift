//
//  InsertUpdateViewController.swift
//  SqliteTask
//
//  Created by eAlphaMac2 on 25/09/20.
//

import UIKit

class InsertUpdateViewController: UIViewController {
    var data: ModelClass!
    @IBOutlet weak var scrollview: UIScrollView!
    @IBOutlet weak var listView: UIView!
    @IBOutlet weak var assertID: UITextField!
    @IBOutlet weak var statusTxtFld: UITextField!
    @IBOutlet weak var healthTxtFld: UITextField!
    @IBOutlet weak var lifeTxtFld: UITextField!
    @IBOutlet weak var saveButton: UIButton!
    @IBOutlet weak var dateTxtFld: UITextField!
    @IBOutlet weak var picker: UIDatePicker!
    var db:DataBaseView = DataBaseView()
    override func viewDidLoad() {
        super.viewDidLoad()
        guard data != nil else {
            saveButton.setTitle("INSERT", for: .normal)
            return
        }
        saveButton.setTitle("UPDATE", for: .normal)
        assertID.text = String(data.AssertID)
        statusTxtFld.text = data.battery_Status
        healthTxtFld.text = data.battery_Health
        lifeTxtFld.text = data.battery_Useful_Life
        //dateTxtFld.text = data.Create_date
        let dateformatter = DateFormatter()
        dateformatter.dateStyle = .medium
        let dateee = dateformatter.date(from: data.Create_date)
        picker.setDate(dateee!, animated: true)
        
    }
    @IBAction func backAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func saveAction(_ sender: Any) {
        let  assertid = assertID.text
        let status = statusTxtFld.text
        let health = healthTxtFld.text
        let life = lifeTxtFld.text
        let dateformatter = DateFormatter()
        dateformatter.dateStyle = .medium
        //self.dateTxtFld.text = dateformatter.string(from: picker.date)
        let date = dateformatter.string(from: picker.date)

        guard data != nil else {
        db.insert(Id: 0, assertID: Int(assertid!)!, battery_status: status!, battery_health: health!, battery_life: life!, created_date: date, flag: "0")
        print(status!,health!,life!,date)
            self.navigationController?.popViewController(animated: true)

            return
            
        }
        db.Update(Id: data.Id, assertID: Int(assertid!)!, battery_status: status!, battery_health: health!, battery_life: life!, created_date: date, flag: "1")
        self.navigationController?.popViewController(animated: true)

    }
    @IBAction func dateAction(_ sender: Any) {
        showDatePicker()
    }
    func showDatePicker(){
       //Formate Date
        picker.isHidden = false
        picker.datePickerMode = .date

        //ToolBar
       let toolbar = UIToolbar();
       toolbar.sizeToFit()

       //done button & cancel button
        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItem.Style.bordered, target: self, action: Selector(("donedatePicker")))
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: UIBarButtonItem.Style.bordered, target: self, action: Selector(("cancelDatePicker")))
       toolbar.setItems([doneButton,spaceButton,cancelButton], animated: false)

    // add toolbar to textField
        dateTxtFld.inputAccessoryView = toolbar
     // add datepicker to textField
    dateTxtFld.inputView = picker

       }

     func donedatePicker(){
      //For date formate
       let formatter = DateFormatter()
       formatter.dateFormat = "dd/MM/yyyy"
        dateTxtFld.text = formatter.string(from: picker.date)
       //dismiss date picker dialog
       self.view.endEditing(true)
        }

          func cancelDatePicker(){
           //cancel button dismiss datepicker dialog
            self.view.endEditing(true)
          }
       

   

}
